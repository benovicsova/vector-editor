import { useState } from "react";

import { TOOL } from "./constants";
import { initialShapes } from "./data/initialShapes";

import Toolbar from "./components/Toolbar";
import EditorCanvas from "./components/EditorCanvas";

import { exportSvg } from "./utils/svgExport";
import { downloadTextFile } from "./utils/fileDownload";
import { duplicateShape } from "./utils/geometry";

export default function App() {
  const [tool, setTool] = useState(TOOL.SELECT);

  const [history, setHistory] = useState([initialShapes]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const shapes = history[historyIndex];

  const [selectedId, setSelectedId] = useState(null);

  const [fill, setFill] = useState("#855cd6");
  const [stroke, setStroke] = useState("#1f2937");
  const [strokeWidth, setStrokeWidth] = useState(4);

  const [zoom, setZoom] = useState(1);

  const [draft, setDraft] = useState(null);
  const [dragInfo, setDragInfo] = useState(null);

  const selectedShape = shapes.find((shape) => shape.id === selectedId) ?? null;

  function commitShapes(nextShapes) {
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIndex + 1);
      return [...sliced, nextShapes];
    });

    setHistoryIndex((prev) => prev + 1);
  }

  function setShapesDirect(updater) {
    const nextShapes = typeof updater === "function" ? updater(shapes) : updater;
    commitShapes(nextShapes);
  }

  function setShapesLive(updater) {
    const nextShapes = typeof updater === "function" ? updater(shapes) : updater;

    setHistory((prev) =>
      prev.map((item, index) => (index === historyIndex ? nextShapes : item))
    );
  }

  function undo() {
    if (historyIndex <= 0) return;
    setHistoryIndex((prev) => prev - 1);
    setSelectedId(null);
  }

  function redo() {
    if (historyIndex >= history.length - 1) return;
    setHistoryIndex((prev) => prev + 1);
    setSelectedId(null);
  }

  function zoomIn() {
    setZoom((prev) => Math.min(prev + 0.25, 4));
  }

  function zoomOut() {
    setZoom((prev) => Math.max(prev - 0.25, 0.25));
  }

  function resetZoom() {
    setZoom(1);
  }

  function duplicateSelected() {
    if (!selectedShape) return;

    const copy = duplicateShape(selectedShape);
    setShapesDirect((prev) => [...prev, copy]);
    setSelectedId(copy.id);
  }

  function deleteSelected() {
    if (!selectedShape) return;

    setShapesDirect((prev) => prev.filter((shape) => shape.id !== selectedId));
    setSelectedId(null);
  }

  function moveLayer(direction) {
    if (!selectedShape) return;

    const index = shapes.findIndex((shape) => shape.id === selectedId);
    const swapIndex = direction === "up" ? index + 1 : index - 1;

    if (swapIndex < 0 || swapIndex >= shapes.length) return;

    const next = [...shapes];
    [next[index], next[swapIndex]] = [next[swapIndex], next[index]];

    setShapesDirect(next);
  }

  function toggleVisible() {
    if (!selectedShape) return;

    setShapesDirect((prev) =>
      prev.map((shape) =>
        shape.id === selectedId ? { ...shape, visible: !shape.visible } : shape
      )
    );
  }

  function handleExportSvg() {
    downloadTextFile("obrazok.svg", exportSvg(shapes), "image/svg+xml");
  }

  function handleExportJson() {
    downloadTextFile(
      "projekt-vektor-editor.json",
      JSON.stringify(shapes, null, 2),
      "application/json"
    );
  }

  function handleImportJson(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);

        if (Array.isArray(data)) {
          commitShapes(data);
          setSelectedId(data[0]?.id ?? null);
        }
      } catch {
        alert("Import JSON súboru zlyhal.");
      }
    };

    reader.readAsText(file);
  }

  return (
    <div className="scratch-app">
      <Toolbar
        tool={tool}
        setTool={setTool}
        fill={fill}
        setFill={setFill}
        stroke={stroke}
        setStroke={setStroke}
        strokeWidth={strokeWidth}
        setStrokeWidth={setStrokeWidth}
        onExportSvg={handleExportSvg}
        onExportJson={handleExportJson}
        onImportJson={handleImportJson}
        onUndo={undo}
        onRedo={redo}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        selectedShape={selectedShape}
        onDuplicate={duplicateSelected}
        onDelete={deleteSelected}
        onMoveForward={() => moveLayer("up")}
        onMoveBackward={() => moveLayer("down")}
        onToggleVisible={toggleVisible}
        zoom={zoom}
        onZoomIn={zoomIn}
        onZoomOut={zoomOut}
        onResetZoom={resetZoom}
      />

      <EditorCanvas
        tool={tool}
        shapes={shapes}
        setShapes={setShapesDirect}
        setShapesLive={setShapesLive}
        selectedId={selectedId}
        setSelectedId={setSelectedId}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
        draft={draft}
        setDraft={setDraft}
        dragInfo={dragInfo}
        setDragInfo={setDragInfo}
        zoom={zoom}
        setZoom={setZoom}
      />
    </div>
  );
}